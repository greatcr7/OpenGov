=====
Usage
=====

To use OpenGov in a project::

    import opengov

To save typing::

    import opengov as og
