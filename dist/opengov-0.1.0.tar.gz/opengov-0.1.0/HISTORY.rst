=======
History
=======

0.1.0 (2020-07-29)
------------------

* First release on PyPI.
