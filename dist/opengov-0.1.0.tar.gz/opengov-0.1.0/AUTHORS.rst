=======
Credits
=======

Development Lead
----------------

* Brandon Jin
* Proud Tartan
* Email: brandonjincmu@gmail.com
* LinkedIn: www.linkedin.com/in/brandon-jin
* GitHub: greatcr7

Contributors
------------

Why not join us now?
