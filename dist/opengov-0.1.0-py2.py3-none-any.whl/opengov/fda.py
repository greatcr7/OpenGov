''' FDA Module '''
import requests
